interface top_if #() (input clk);

logic	rst_n;
//写数�?
logic	[31:0] dina;
logic	[31:0] addra;
logic	ena;
logic	wea;			//本来应该�?4bit，但写的模块只能�?1bit，没影响
//接收结果
logic led0;
logic led1;

//时钟�?
clocking cb @(posedge clk);
	input	led0, led1;
	output	dina, addra, wea, ena;
endclocking : cb

modport tb (
	clocking cb,
	output rst_n
);

endinterface : top_if