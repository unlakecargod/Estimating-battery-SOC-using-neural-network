program automatic top_tb #(parameter CNT_MAX = 50) (top_if.tb iftb);

localparam file = "../../../../tb/input.txt";
//31�?16为u�? 
logic [31:0] data [59:0];

initial begin
    ram_ini();
	rst();
	$display("wx1[0]:%x", u_top.u_lstm_top.u_memory.u_wx1.inst.native_mem_module.blk_mem_gen_v8_4_4_inst.memory[0]);
	$display("feature[0]:%x", u_top.u_feature.u_f1.inst.native_mem_module.blk_mem_gen_v8_4_4_inst.memory[0]);
	update();
	@iftb.cb.led1;
	$display("calculate done !");
	repeat(5)
		@iftb.cb;
	print();
	$stop;
end

//复位
task rst;
	iftb.rst_n <= 0;
	repeat(10)
		@iftb.cb;
	iftb.rst_n <= 1;
	repeat(10)
		@iftb.cb;
	$display("reset done !");
endtask

task ram_ini;
	$readmemb(file, data);
	repeat(50)
		@iftb.cb;
	$display("ram_ini done !");
endtask

//更新数据
//地址0存u的低8�?
//地址4存u的高8�?
//地址8存i的低8�?
//地址12存i的高8�?
task update();
	integer i;
	for (i=0;i<60;i=i+1) begin
		iftb.cb.addra <= 0;
		iftb.cb.dina <= data[i][23:16];
		iftb.cb.wea <= 1;
		iftb.cb.ena <= 1;
		@iftb.cb;
		iftb.cb.addra <= 4;
		iftb.cb.dina <= data[i][31:24];
		@iftb.cb;
		iftb.cb.addra <= 8;
		iftb.cb.dina <= data[i][7:0];
		@iftb.cb;
		iftb.cb.addra <= 12;
		iftb.cb.dina <= data[i][15:8];
	 	@iftb.cb;
		iftb.cb.wea <= 0;
		iftb.cb.ena <= 0;
		repeat(CNT_MAX)
			@iftb.cb;
		$display("data refresh !");
	end
endtask

task print();
	integer i;
	for (i=0;i<16;i=i+1) begin
	   $display("x_in:%d", $signed(u_top.u_lstm_top.u_memory.x.RAM_MEM[i]));
	end
	$display("result:%d", u_dual_port_ram.inst.native_mem_module.blk_mem_gen_v8_4_4_inst.memory[24]);
endtask




endprogram :  top_tb