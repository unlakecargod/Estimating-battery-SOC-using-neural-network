module top_top #(
	parameter 
	DATA_WIDTH 	= 16,
	INPUT_SIZE 	= 8,
	HIDDEN_SIZE = 64,
	SEQ_LEN 	= 30,
	ADD_WIDTH 	= 16,
	FRACT_WIDTH = 12,
	FC_BIAS     = 16'b0000001110011111, //���Բ��ƫ��
	U_REC		= 16'd18137,		    //Umax - Umin�ĵ���
	I_REC		= 16'd26843,		    //Imax - Imin�ĵ���
	Q_REC		= 16'd19088,		//�������ĵ�����
	U_MIN_NEG	= -24'd2400,		//��Umin
	I_MIN_NEG	= 24'd0,			//��Imin
	INI_Q		= 24'd6707848,		//��ʼ��������λmas
	IN_WIDTH_1 	= 24,
	IN_WIDTH_2 	= 16,
	SCALE		= 12,
	CNT_MAX 	= 150_000,
	SLEEP_TIME 	= 3600,		   	//����������޸��ؽ���˯��ģʽ
	I_LOW 		= 8'd10,			//����������ڶ�����Ϊ�޸�??
	U_SCALE 	= 25,
	I_SCALE 	= 28,
	Q_SCALE 	= 37
) ();

//生成时钟信号
parameter clock_period = 20;
bit clk;

initial begin
	$timeformat(-9, 1, "ns", 10);
	clk = 0;
	forever begin
		#(clock_period / 2);
		clk = ~clk;
	end
end

logic clkb;
logic enb;
logic web;
logic [31:0] addrb;
logic [31:0] doutb;
logic [31:0] dinb;

//例化�?个ram模拟bram
blk_mem_gen_0 #(.DEPTH(28), .WIDTH(32), .ADD_WIDTH(32)) u_dual_port_ram (
	.clka (clk ),
	.ena  (tpif.ena  ),
	.wea  (tpif.wea  ),
	.addra(tpif.addra),
	.dina (tpif.dina ),
	.douta(    ),
	.clkb (clkb ),
	.enb  (enb  ),
	.web  (web  ),
	.addrb(addrb),
	.dinb (dinb ),
	.doutb(doutb)
);

//例化待测试模�?
top #(
	.DATA_WIDTH (DATA_WIDTH ),
	.INPUT_SIZE (INPUT_SIZE ),
	.HIDDEN_SIZE(HIDDEN_SIZE),
	.SEQ_LEN    (SEQ_LEN    ),
	.ADD_WIDTH  (ADD_WIDTH  ),
	.FRACT_WIDTH(FRACT_WIDTH),
	.FC_BIAS    (FC_BIAS    ),
	.U_REC      (U_REC      ),
	.I_REC      (I_REC      ),
	.Q_REC      (Q_REC      ),
	.U_MIN_NEG  (U_MIN_NEG  ),
	.I_MIN_NEG  (I_MIN_NEG  ),
	.INI_Q      (INI_Q      ),
	.IN_WIDTH_1 (IN_WIDTH_1 ),
	.IN_WIDTH_2 (IN_WIDTH_2 ),
	.SCALE      (SCALE      ),
	.CNT_MAX    (CNT_MAX    ),
	.SLEEP_TIME (SLEEP_TIME ),
	.I_LOW      (I_LOW      ),
	.U_SCALE    (U_SCALE    ),
	.I_SCALE    (I_SCALE    ),
	.Q_SCALE    (Q_SCALE    )
) u_top (
	.clk    (clk    	),
	.rst_n  (tpif.rst_n ),
	.data   (doutb  	),
	.ram_clk(clkb		),
	.ram_rst(       	),
	.addr   (addrb 		),
	.rd_en  (enb  		),
	.we     (web		),
	.wr_data(dinb		),
	.led0 (tpif.led0),
	.led1 (tpif.led1)
);

//例化接口
top_if tpif (
	.clk(clk)
);

//例化testbench
top_tb #(.CNT_MAX(CNT_MAX)) u_top_tb (
	.iftb(tpif.tb)
);


endmodule