# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  ipgui::add_param $IPINST -name "ADD_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "CNT_MAX" -parent ${Page_0}
  ipgui::add_param $IPINST -name "DATA_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FC_BIAS" -parent ${Page_0}
  ipgui::add_param $IPINST -name "FRACT_WIDTH" -parent ${Page_0}
  ipgui::add_param $IPINST -name "HIDDEN_SIZE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "INI_Q" -parent ${Page_0}
  ipgui::add_param $IPINST -name "INPUT_SIZE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "IN_WIDTH_1" -parent ${Page_0}
  ipgui::add_param $IPINST -name "IN_WIDTH_2" -parent ${Page_0}
  ipgui::add_param $IPINST -name "I_LOW" -parent ${Page_0}
  ipgui::add_param $IPINST -name "I_MIN_NEG" -parent ${Page_0}
  ipgui::add_param $IPINST -name "I_REC" -parent ${Page_0}
  ipgui::add_param $IPINST -name "Q_REC" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SCALE" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SEQ_LEN" -parent ${Page_0}
  ipgui::add_param $IPINST -name "SLEEP_TIME" -parent ${Page_0}
  ipgui::add_param $IPINST -name "U_MIN_NEG" -parent ${Page_0}
  ipgui::add_param $IPINST -name "U_REC" -parent ${Page_0}

  ipgui::add_param $IPINST -name "U_SCALE"
  ipgui::add_param $IPINST -name "I_SCALE"
  ipgui::add_param $IPINST -name "Q_SCALE"
  ipgui::add_param $IPINST -name "LED0_MAX"
  ipgui::add_param $IPINST -name "LED1_MAX"

}

proc update_PARAM_VALUE.ADD_WIDTH { PARAM_VALUE.ADD_WIDTH } {
	# Procedure called to update ADD_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ADD_WIDTH { PARAM_VALUE.ADD_WIDTH } {
	# Procedure called to validate ADD_WIDTH
	return true
}

proc update_PARAM_VALUE.CNT_MAX { PARAM_VALUE.CNT_MAX } {
	# Procedure called to update CNT_MAX when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.CNT_MAX { PARAM_VALUE.CNT_MAX } {
	# Procedure called to validate CNT_MAX
	return true
}

proc update_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to update DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DATA_WIDTH { PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to validate DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.FC_BIAS { PARAM_VALUE.FC_BIAS } {
	# Procedure called to update FC_BIAS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FC_BIAS { PARAM_VALUE.FC_BIAS } {
	# Procedure called to validate FC_BIAS
	return true
}

proc update_PARAM_VALUE.FRACT_WIDTH { PARAM_VALUE.FRACT_WIDTH } {
	# Procedure called to update FRACT_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.FRACT_WIDTH { PARAM_VALUE.FRACT_WIDTH } {
	# Procedure called to validate FRACT_WIDTH
	return true
}

proc update_PARAM_VALUE.HIDDEN_SIZE { PARAM_VALUE.HIDDEN_SIZE } {
	# Procedure called to update HIDDEN_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.HIDDEN_SIZE { PARAM_VALUE.HIDDEN_SIZE } {
	# Procedure called to validate HIDDEN_SIZE
	return true
}

proc update_PARAM_VALUE.INI_Q { PARAM_VALUE.INI_Q } {
	# Procedure called to update INI_Q when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.INI_Q { PARAM_VALUE.INI_Q } {
	# Procedure called to validate INI_Q
	return true
}

proc update_PARAM_VALUE.INPUT_SIZE { PARAM_VALUE.INPUT_SIZE } {
	# Procedure called to update INPUT_SIZE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.INPUT_SIZE { PARAM_VALUE.INPUT_SIZE } {
	# Procedure called to validate INPUT_SIZE
	return true
}

proc update_PARAM_VALUE.IN_WIDTH_1 { PARAM_VALUE.IN_WIDTH_1 } {
	# Procedure called to update IN_WIDTH_1 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IN_WIDTH_1 { PARAM_VALUE.IN_WIDTH_1 } {
	# Procedure called to validate IN_WIDTH_1
	return true
}

proc update_PARAM_VALUE.IN_WIDTH_2 { PARAM_VALUE.IN_WIDTH_2 } {
	# Procedure called to update IN_WIDTH_2 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IN_WIDTH_2 { PARAM_VALUE.IN_WIDTH_2 } {
	# Procedure called to validate IN_WIDTH_2
	return true
}

proc update_PARAM_VALUE.I_LOW { PARAM_VALUE.I_LOW } {
	# Procedure called to update I_LOW when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.I_LOW { PARAM_VALUE.I_LOW } {
	# Procedure called to validate I_LOW
	return true
}

proc update_PARAM_VALUE.I_MIN_NEG { PARAM_VALUE.I_MIN_NEG } {
	# Procedure called to update I_MIN_NEG when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.I_MIN_NEG { PARAM_VALUE.I_MIN_NEG } {
	# Procedure called to validate I_MIN_NEG
	return true
}

proc update_PARAM_VALUE.I_REC { PARAM_VALUE.I_REC } {
	# Procedure called to update I_REC when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.I_REC { PARAM_VALUE.I_REC } {
	# Procedure called to validate I_REC
	return true
}

proc update_PARAM_VALUE.I_SCALE { PARAM_VALUE.I_SCALE } {
	# Procedure called to update I_SCALE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.I_SCALE { PARAM_VALUE.I_SCALE } {
	# Procedure called to validate I_SCALE
	return true
}

proc update_PARAM_VALUE.LED0_MAX { PARAM_VALUE.LED0_MAX } {
	# Procedure called to update LED0_MAX when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LED0_MAX { PARAM_VALUE.LED0_MAX } {
	# Procedure called to validate LED0_MAX
	return true
}

proc update_PARAM_VALUE.LED1_MAX { PARAM_VALUE.LED1_MAX } {
	# Procedure called to update LED1_MAX when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.LED1_MAX { PARAM_VALUE.LED1_MAX } {
	# Procedure called to validate LED1_MAX
	return true
}

proc update_PARAM_VALUE.Q_REC { PARAM_VALUE.Q_REC } {
	# Procedure called to update Q_REC when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.Q_REC { PARAM_VALUE.Q_REC } {
	# Procedure called to validate Q_REC
	return true
}

proc update_PARAM_VALUE.Q_SCALE { PARAM_VALUE.Q_SCALE } {
	# Procedure called to update Q_SCALE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.Q_SCALE { PARAM_VALUE.Q_SCALE } {
	# Procedure called to validate Q_SCALE
	return true
}

proc update_PARAM_VALUE.SCALE { PARAM_VALUE.SCALE } {
	# Procedure called to update SCALE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SCALE { PARAM_VALUE.SCALE } {
	# Procedure called to validate SCALE
	return true
}

proc update_PARAM_VALUE.SEQ_LEN { PARAM_VALUE.SEQ_LEN } {
	# Procedure called to update SEQ_LEN when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SEQ_LEN { PARAM_VALUE.SEQ_LEN } {
	# Procedure called to validate SEQ_LEN
	return true
}

proc update_PARAM_VALUE.SLEEP_TIME { PARAM_VALUE.SLEEP_TIME } {
	# Procedure called to update SLEEP_TIME when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SLEEP_TIME { PARAM_VALUE.SLEEP_TIME } {
	# Procedure called to validate SLEEP_TIME
	return true
}

proc update_PARAM_VALUE.U_MIN_NEG { PARAM_VALUE.U_MIN_NEG } {
	# Procedure called to update U_MIN_NEG when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.U_MIN_NEG { PARAM_VALUE.U_MIN_NEG } {
	# Procedure called to validate U_MIN_NEG
	return true
}

proc update_PARAM_VALUE.U_REC { PARAM_VALUE.U_REC } {
	# Procedure called to update U_REC when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.U_REC { PARAM_VALUE.U_REC } {
	# Procedure called to validate U_REC
	return true
}

proc update_PARAM_VALUE.U_SCALE { PARAM_VALUE.U_SCALE } {
	# Procedure called to update U_SCALE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.U_SCALE { PARAM_VALUE.U_SCALE } {
	# Procedure called to validate U_SCALE
	return true
}


proc update_MODELPARAM_VALUE.DATA_WIDTH { MODELPARAM_VALUE.DATA_WIDTH PARAM_VALUE.DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DATA_WIDTH}] ${MODELPARAM_VALUE.DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.INPUT_SIZE { MODELPARAM_VALUE.INPUT_SIZE PARAM_VALUE.INPUT_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.INPUT_SIZE}] ${MODELPARAM_VALUE.INPUT_SIZE}
}

proc update_MODELPARAM_VALUE.HIDDEN_SIZE { MODELPARAM_VALUE.HIDDEN_SIZE PARAM_VALUE.HIDDEN_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.HIDDEN_SIZE}] ${MODELPARAM_VALUE.HIDDEN_SIZE}
}

proc update_MODELPARAM_VALUE.SEQ_LEN { MODELPARAM_VALUE.SEQ_LEN PARAM_VALUE.SEQ_LEN } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SEQ_LEN}] ${MODELPARAM_VALUE.SEQ_LEN}
}

proc update_MODELPARAM_VALUE.ADD_WIDTH { MODELPARAM_VALUE.ADD_WIDTH PARAM_VALUE.ADD_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ADD_WIDTH}] ${MODELPARAM_VALUE.ADD_WIDTH}
}

proc update_MODELPARAM_VALUE.FRACT_WIDTH { MODELPARAM_VALUE.FRACT_WIDTH PARAM_VALUE.FRACT_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FRACT_WIDTH}] ${MODELPARAM_VALUE.FRACT_WIDTH}
}

proc update_MODELPARAM_VALUE.FC_BIAS { MODELPARAM_VALUE.FC_BIAS PARAM_VALUE.FC_BIAS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.FC_BIAS}] ${MODELPARAM_VALUE.FC_BIAS}
}

proc update_MODELPARAM_VALUE.U_REC { MODELPARAM_VALUE.U_REC PARAM_VALUE.U_REC } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.U_REC}] ${MODELPARAM_VALUE.U_REC}
}

proc update_MODELPARAM_VALUE.I_REC { MODELPARAM_VALUE.I_REC PARAM_VALUE.I_REC } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.I_REC}] ${MODELPARAM_VALUE.I_REC}
}

proc update_MODELPARAM_VALUE.Q_REC { MODELPARAM_VALUE.Q_REC PARAM_VALUE.Q_REC } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.Q_REC}] ${MODELPARAM_VALUE.Q_REC}
}

proc update_MODELPARAM_VALUE.U_MIN_NEG { MODELPARAM_VALUE.U_MIN_NEG PARAM_VALUE.U_MIN_NEG } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.U_MIN_NEG}] ${MODELPARAM_VALUE.U_MIN_NEG}
}

proc update_MODELPARAM_VALUE.I_MIN_NEG { MODELPARAM_VALUE.I_MIN_NEG PARAM_VALUE.I_MIN_NEG } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.I_MIN_NEG}] ${MODELPARAM_VALUE.I_MIN_NEG}
}

proc update_MODELPARAM_VALUE.INI_Q { MODELPARAM_VALUE.INI_Q PARAM_VALUE.INI_Q } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.INI_Q}] ${MODELPARAM_VALUE.INI_Q}
}

proc update_MODELPARAM_VALUE.IN_WIDTH_1 { MODELPARAM_VALUE.IN_WIDTH_1 PARAM_VALUE.IN_WIDTH_1 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IN_WIDTH_1}] ${MODELPARAM_VALUE.IN_WIDTH_1}
}

proc update_MODELPARAM_VALUE.IN_WIDTH_2 { MODELPARAM_VALUE.IN_WIDTH_2 PARAM_VALUE.IN_WIDTH_2 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IN_WIDTH_2}] ${MODELPARAM_VALUE.IN_WIDTH_2}
}

proc update_MODELPARAM_VALUE.SCALE { MODELPARAM_VALUE.SCALE PARAM_VALUE.SCALE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SCALE}] ${MODELPARAM_VALUE.SCALE}
}

proc update_MODELPARAM_VALUE.CNT_MAX { MODELPARAM_VALUE.CNT_MAX PARAM_VALUE.CNT_MAX } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.CNT_MAX}] ${MODELPARAM_VALUE.CNT_MAX}
}

proc update_MODELPARAM_VALUE.SLEEP_TIME { MODELPARAM_VALUE.SLEEP_TIME PARAM_VALUE.SLEEP_TIME } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SLEEP_TIME}] ${MODELPARAM_VALUE.SLEEP_TIME}
}

proc update_MODELPARAM_VALUE.I_LOW { MODELPARAM_VALUE.I_LOW PARAM_VALUE.I_LOW } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.I_LOW}] ${MODELPARAM_VALUE.I_LOW}
}

proc update_MODELPARAM_VALUE.U_SCALE { MODELPARAM_VALUE.U_SCALE PARAM_VALUE.U_SCALE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.U_SCALE}] ${MODELPARAM_VALUE.U_SCALE}
}

proc update_MODELPARAM_VALUE.I_SCALE { MODELPARAM_VALUE.I_SCALE PARAM_VALUE.I_SCALE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.I_SCALE}] ${MODELPARAM_VALUE.I_SCALE}
}

proc update_MODELPARAM_VALUE.Q_SCALE { MODELPARAM_VALUE.Q_SCALE PARAM_VALUE.Q_SCALE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.Q_SCALE}] ${MODELPARAM_VALUE.Q_SCALE}
}

proc update_MODELPARAM_VALUE.LED0_MAX { MODELPARAM_VALUE.LED0_MAX PARAM_VALUE.LED0_MAX } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LED0_MAX}] ${MODELPARAM_VALUE.LED0_MAX}
}

proc update_MODELPARAM_VALUE.LED1_MAX { MODELPARAM_VALUE.LED1_MAX PARAM_VALUE.LED1_MAX } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.LED1_MAX}] ${MODELPARAM_VALUE.LED1_MAX}
}

