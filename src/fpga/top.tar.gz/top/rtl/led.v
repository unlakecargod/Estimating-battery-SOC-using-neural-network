module led
#(
    parameter CNT0_MAX = 1_000_000,
    parameter CNT1_MAX = 2_000_000
)
(
    input clk,
    input   rst_n,
    //���ݸ���ָʾ��
    input   rd_en,
    output   reg    led0,
    //���ָʾ��
    input   finish,
    output  reg led1
);

reg [$clog2(CNT0_MAX)-1:0] cnt0;
reg [$clog2(CNT1_MAX)-1:0] cnt1;

always @(posedge clk, negedge rst_n) begin
    if (~rst_n)
        cnt0 <= 0;
    else if (led0)
        cnt0 <= cnt0 == CNT0_MAX ? 0 : cnt0 + 1;
end

always @(posedge clk, negedge rst_n) begin
    if (~rst_n)
        cnt1 <= 0;
    else if (led1)
        cnt1 <= cnt1 == CNT1_MAX ? 0 : cnt1 + 1;
end

always @(posedge clk, negedge rst_n) begin
    if (~rst_n)
        led0 <= 0;
    else if (rd_en)
        led0 <= 1;
    else if (cnt0 == CNT0_MAX)
        led0 <= 0;
end

always @(posedge clk, negedge rst_n) begin
    if (~rst_n)
        led1 <= 0;
    else if (finish)
        led1 <= 1;
    else if (cnt1 == CNT1_MAX)
        led1 <= 0;
end


endmodule