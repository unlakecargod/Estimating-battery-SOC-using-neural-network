 module mode_set 
 #(
 	CNT_MAX 	= 50_000_000,
	SLEEP_TIME 	= 3600,		   	//定义多少秒无负载进入睡眠模式
	I_LOW 		= 8'd10			//定义电流低于多少认为无负�??
 ) 
 (
 	input 				clk,
 	input 				rst_n,
	//BRAMPORT 
	input		[31:0]	data,
	output				ram_clk,
	output				ram_rst,
	output 	reg	[31:0] 	addr,
	output  reg         rd_en,
	output	reg	[3:0]	we,
	output	reg	[31:0]  wr_data,
	//
	output	reg			valid0,
	output	reg			valid1,
	output	reg	[15:0]	u_reg,
	output	reg	[15:0]	i_reg,
	//接收计算结果
	input				finish,
	input		[15:0]	result
 );

 localparam cnt_width = $clog2(CNT_MAX);

 reg [cnt_width-1 : 0] cnt;		//计数

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		cnt <= 0;
	end
	else begin
		cnt <= cnt == CNT_MAX ? 0 : cnt + 1;
	end
end
 
//数据刷新标志信号
reg fresh_en;
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		fresh_en <= 1'b0;
	end
	else begin
		fresh_en <= cnt==CNT_MAX;
	end
end

reg [3:0] state;	//状�?�标志信�??

always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		state <= 0;
	end
	else begin
		if (fresh_en)
			state <= 1;
		else if (state!=0)
			state <= state==8 ? 0 : state + 1;
		else
			state <= state;
	end
end

//产生读使能信�??
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		rd_en <= 1'b0;
	end
	else begin
		if (fresh_en || finish)
			rd_en <= 1'b1;
		else begin
			case(state)
				1: rd_en <= 1'b1;
				2: rd_en <= 1'b1;
				3: rd_en <= 1'b1;
				default: rd_en <= 1'b0;
			endcase
		end
	end
end

//产生地址信号
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		addr <= 0;
	end
	else begin
		case(state)
			0: addr <= 0;
			1: addr <= 4;
			2: addr <= 8;
			3: addr <= 12;
		endcase
		if (finish)
			addr <= 24;
	end
end

//产生写使�?
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		we <= 4'b0000;
	end
	else begin
		if (finish)
			we <= 4'b1111;
		else
			we <= 4'b0000;
	end
end

//产生写数�?
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		wr_data <= 32'd0;
	end
	else begin
		if (finish)
			wr_data <= {16'd0, result};
	end
end

//采样ui数据
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		u_reg <= 16'd0;
		i_reg <= 16'd0;
	end
	else begin
		case(state)
			2: u_reg <= data[15:0];
			3: u_reg <= {data[7:0], u_reg[7:0]};
			4: i_reg <= data[15:0];
			5: i_reg <= {data[7:0], i_reg[7:0]};
		endcase
	end
end


reg mode; 	//模式0代表计算模式�??1代表休眠模式
reg [$clog2(SLEEP_TIME)-1 : 0] unload_cnt;

//模式切换逻辑
//在s7时决定模�?
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		mode <= 1'd0;
	end
	else begin
		if (state==7)
			case(mode)
				0: mode <= unload_cnt==SLEEP_TIME ? 1 : mode;
				1: mode <= (i_reg <= I_LOW) ? 0 : mode;
			endcase
	end
end 

//无负载计时器
//只在模式0计数，模�?1不计�?
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		unload_cnt <= 0;
	end
	else begin
		if (state==6)
			if (~mode && i_reg <= I_LOW)
				unload_cnt <= unload_cnt + 1;
			else
				unload_cnt <= 0;
	end
end

//数据采样完成标志信号
always @(posedge clk or negedge rst_n) begin
	if (!rst_n) begin
		valid0 <= 1'd0;
		valid1 <= 1'd0;
	end
	else begin
		if (state==8) begin
			valid0 <= ~mode;
			valid1 <= mode;
		end
		else begin
			valid0 <= 0;
			valid1 <= 0;
		end
	end
end

//bram
assign ram_clk = clk;
assign ram_rst = ~rst_n;


endmodule